<?php
session_start();

if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = [];
}

if (isset($_POST['id']) && isset($_POST['nombre']) && isset($_POST['precio'])&& isset($_POST['img'])) {
    $producto = [
        'id' => $_POST['id'],
        'nombre' => $_POST['nombre'],
        'precio' => (float)$_POST['precio'],
        'img' => $_POST['img']
    ];
    $_SESSION['carrito'][] = $producto;
    echo "Producto agregado al carrito";
}
?>
