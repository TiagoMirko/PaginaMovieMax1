<?php
session_start();

$servername = "127.0.0.1";
$username = "alumno";
$password = "alumnoipm";
$database = "basededatosmoviemax3__";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
$numeroRecibo = rand(1000, 9999) . '-' . rand(1000, 9999);
$numeroFactura = rand(100000000, 999999999) . '-0000';


$numeroTarjeta = $_SESSION['numeroTarjeta'] ?? '************0000'; 
$ultimosDigitos = substr($numeroTarjeta, -2); 
$metodoPago = "**** **** **** $ultimosDigitos";


$numeroTarjeta = $_SESSION['numeroTarjeta'] ?? null;
$total = isset($_SESSION['total_compra']) ? $_SESSION['total_compra'] : 0;
if ($numeroTarjeta) {
  
    $consultaTarjeta = "SELECT * FROM tarjeta WHERE numeroTarjeta = '$numeroTarjeta'";
    $resultadoTarjeta = $conn->query($consultaTarjeta);

    if ($resultadoTarjeta && $resultadoTarjeta->num_rows > 0) {
        $tarjeta = $resultadoTarjeta->fetch_assoc();
    } else {
        echo "No se encontró información de la tarjeta.";
    }
} else {
    echo "El número de tarjeta no está definido en la sesión.";
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Detalles de Compra</title>
    <link rel="stylesheet" href="detallesCompra.css">
    <link rel="icon" href="PeliculaImagenes/logoPrincipio.png">
</head>
<body>

<div class="container">
    <div class="header">
        <h1>Recibo de Compra</h1>
        <p>Pagado el <?php echo date("d M, Y"); ?></p>
        <p class="amount">$<?php echo number_format($total, 2); ?></p>
      
        <div class="info">
            <p>Número de recibo</p>
            <p><?php echo $numeroRecibo; ?></p>
        </div>
        <div class="info">
            <p>Número de factura</p>
            <p><?php echo $numeroFactura; ?></p>
        </div>
        <div class="info">
            <p>Método de pago</p>
            <p><?php echo $metodoPago; ?></p>
        </div>
    </div>

    <div class="summary">
        <h2>Resumen del Pedido</h2>
        <?php foreach ($_SESSION['carrito'] as $producto): ?>
            <div class="item">
                <img src="<?php echo htmlspecialchars($producto['img']); ?>" alt="Imagen de <?php echo htmlspecialchars($producto['nombre']); ?>">
                <div class="item-details">
                    <p class="title"><?php echo htmlspecialchars($producto['nombre']); ?></p>
                    <p class="price">$<?php echo number_format($producto['precio'], 2); ?></p>
                </div>
            </div>
        <?php endforeach; ?>
        <div class="item">
            <strong>Total</strong>
            <strong>$<?php echo number_format($total, 2); ?></strong>
        </div>
    </div>
    
    <div class="back-button">
            <a href="recibo.php" class="btn">Volver</a> 
        </div>
    </div>

    
</div>

</body>
</html>