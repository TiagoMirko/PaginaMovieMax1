<html>
<head>
<title>Inicio sesion </title>

<link rel="icon" href="1.png">
</head>



<div class="card">
      <div class="content">
        <div class="title">Edicion Standard</div>
        <div class="price">$39.99</div>
        <div class="description">Nos alegra que estés aquí. Prepárate para sumergirte en un mundo de historias cautivadoras y emocionantes. Explora nuestra amplia selección de películas y series, desde los clásicos que nunca pasan de moda hasta los últimos estrenos</div>
      </div>
        <button id="button1" onclick="window.location.href='concesionaria.php'">
          7 dias de prueba
        </button>
  </div>



<style>
/* From Uiverse.io by Yaya12085 */ 
.card {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-around;
  width: 260px;
  padding: 20px 1px;
  margin: 10px 0;
  text-align: center;
  position: relative;
  left: 35%;
  top: 20%;
  cursor: pointer;
  box-shadow: 0 10px 15px -3px rgba(33,150,243,.4),0 4px 6px -4px rgba(33,150,243,.4);
  border-radius: 10px;
  background-color: #6B6ECC;
  background: linear-gradient(45deg, #04051dea 0%, #2b566e 100%);
}

.content {
  padding: 20px;
}

.content .price {
  color: white;
  font-weight: 800;
  font-size: 50px;
  text-shadow: 0px 0px 10px rgba(0, 0, 0, 0.42);
}

.content .description {
  color: rgba(255, 255, 255, 0.6);
  margin-top: 10px;
  font-size: 14px;
}

.content .title {
  font-weight: 800;
  text-transform: uppercase;
  color: rgba(255, 255, 255, 0.64);
  margin-top: 10px;
  font-size: 25px;
  letter-spacing: 1px;
}

#button1 {
  -webkit-user-select: none;
  -moz-user-select: none;
  user-select: none;
  border: none;
  outline: none;
  color: rgb(255 255 255);
  text-transform: uppercase;
  font-weight: 700;
  font-size: .75rem;
  padding: 0.75rem 1.5rem;
  background-color: rgb(33 150 243);
  border-radius: 0.5rem;
  width: 90%;
  text-shadow: 0px 4px 18px #2c3442;
}

</style>


<?php
	$email= $_POST["Email"];
	$contraseña = $_POST["contraseña"];
    $servername = "127.0.0.1";
    $database = "basededatosmoviemax3";
    $username = "alumno";
    $password = "alumnoipm";
    
    $conexion = mysqli_connect($servername, $username, $password, $database); // se crea la conexion


    if (!$conexion) {
        die("Conexion fallida: " . mysqli_connect_error());
    }
    else{
        $query = "select contraseña from usuario where email = '$email'";
        $resultado=mysqli_query($conexion, $query);
        if(mysqli_num_rows($resultado)==0){
            echo "Error no existe usuario con ese nombre";
        }
        else{
            $fila = mysqli_fetch_assoc($resultado);
            if($fila["contraseña"] == $contraseña){
                session_start();
                $_SESSION["Email"]=$email;
                $_SESSION["contraseña"]=$contraseña;
                $_SESSION["iniciada"]=true;
                echo "Iniciaste sesion";
            }else{
                echo "Contra incorrecta";
            }
        }
    }
    mysqli_close($conexion);
?>