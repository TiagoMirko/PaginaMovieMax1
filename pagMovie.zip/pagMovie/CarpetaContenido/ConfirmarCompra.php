<?php
// detallePelicula.php
session_start();
$servername = "127.0.0.1";
$username = "alumno";
$password = "alumnoipm";
$database = "basededatosmoviemax3";

$conexion = mysqli_connect($servername, $username, $password, $database);

if(isset($_GET['id'])){
    $id = $_GET['id'];
    $query = "SELECT nombre, precio FROM pelicula WHERE id = $id";
    $resultado = mysqli_query($conexion, $query);
    
    if($resultado && mysqli_num_rows($resultado) > 0){
        $pelicula = mysqli_fetch_assoc($resultado);
        $nombre = $pelicula['nombre'];
        $precio = $pelicula['precio'];
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="ConfirmarCompra.css">
    <link rel="icon" href="PeliculaImagenes/logoPrincipio.png">
    <title>Confirmar Compra | Movie Max</title>
</head>
<body>


<div class="card"> 
  
  <div class="header"> 
    <div class="image">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><g stroke-width="0" id="SVGRepo_bgCarrier"></g><g stroke-linejoin="round" stroke-linecap="round" id="SVGRepo_tracerCarrier"></g><g id="SVGRepo_iconCarrier"> <path stroke-linejoin="round" stroke-linecap="round" stroke-width="1.5" stroke="#000000" d="M20 7L9.00004 18L3.99994 13"></path> </g></svg>
      </div> 
      <div class="content">
         <span class="title">Pelicula Alquilada!</span> 
         <p class="message">Gracias por comprar en Movie Max, dentro de 48 horas se le enviara un mail con Toda la informacion y con los detalles para rellenar.</p> 
         <p class="message">Pelicula Alquilada:<?php echo htmlspecialchars($nombre); ?></p>
         <p class="message">Precio:<?php echo htmlspecialchars($precio);?>$</p>
         </div> 
         <div class="actions">
            <button   class="history" onclick="window.location.href='concesionaria.php'">Volver al Inicio</button> 
            
            </div> 
            </div> 
            </div>




</body>
</html>