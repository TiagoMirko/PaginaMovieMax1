<?php 
    //conexion con las variables blabal
    $query = "select * from pelicula where categoria = 'terror'";
    $resultado = mysqli_query($conexion, $query);
    
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='prueba.css'>
    <script src='main.js'></script>
</head>
<body>
    <section>
        <h1>Terror</h1>
        <div class="contenedor">
            <?php 
                while($fila = mysqli_fetch_assoc($resultado)){
?>
                    <div class="card" style="background-image: url(scream.jpeg);">
                        <p class="title">Pelicula 1</p>
                    </div>
                 <?php } ?>
        </div>
    </section>
   
</body>
</html></ht>