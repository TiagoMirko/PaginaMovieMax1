CREATE TABLE pelicula (
  id int NOT NULL AUTO_INCREMENT,
  nombre varchar(45) NOT NULL,
  descripcion text,
  fecha_lanzamiento date DEFAULT NULL,
  duracion time DEFAULT NULL,
  acceso enum('gratis','alquiler') DEFAULT NULL,
  precio decimal(4,2) DEFAULT NULL,
  genero varchar(45) DEFAULT NULL,
  PRIMARY KEY (id)
);
CREATE TABLE usuario (
  id int  NOT NULL AUTO_INCREMENT,
  nombre_usuario varchar(45) NOT NULL,
  email varchar(45) NOT NULL,
  fecha_nacimiento date DEFAULT NULL,
  contraseña varchar(45) NOT NULL,
  fecha_registro date DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY email (email)
);