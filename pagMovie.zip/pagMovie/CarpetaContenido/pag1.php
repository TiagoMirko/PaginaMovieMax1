<?php
session_start();
?>
<html>
<head>
<title>Iniciaste sesion </title>
<link rel="stylesheet" href="paginaRegistro.css">
<link rel="icon" href="PeliculaImagenes/logoPrincipio.png">
</head>


<body>


<?php
	$email= $_POST["Email"];
	$contraseña = $_POST["contraseña"];
    $servername = "127.0.0.1";
    $database = "basededatos";
    $username = "alumno";
    $password = "alumnoipm";
    
    $conexion = mysqli_connect($servername, $username, $password, $database); // se crea la conexion


  if (!$conexion) {
        die("Conexion fallida: " . mysqli_connect_error());
    }else 
      {
        $query = "select contraseña from usuario where email = '$email'";
        $resultado=mysqli_query($conexion, $query);
          
        
         if (mysqli_num_rows($resultado)==0)
         {
            ?> 
            <div class="notifications-container">
              <div class="error-alert">
                <div class="flex">
                  <div class="flex-shrink-0">
                    <svg aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" class="error-svg">
                      <path clip-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" fill-rule="evenodd"></path>
                    </svg>
                      </div>
                      <div class="error-prompt-container">
                        <p class="error-prompt-heading">Contraseña Incorrecta
                        </p><div class="error-prompt-wrap">
                          <ul class="error-prompt-list" role="list">
                            <li>El Usuario o Contraseña no existen</li>
                            <li>Use el Usurio o Contraseña adecuado</li>
                            <li><a href="iniciosesion.php">Volver</a> </li>
                            
                          
                    
                          </ul>
                      </div>
                      </div>
                    </div>
                  </div>
                </div>
            <?
          }         
                  else{
            $fila = mysqli_fetch_assoc($resultado);
              if($fila["contraseña"] == $contraseña){
                
                $_SESSION["email"]=$email;
                $_SESSION["contraseña"]=$contraseña;
                $_SESSION["iniciada"]=true;
                
                ?>
                  
                <div id="loader">
                  <div class="ls-particles ls-part-1"></div>
                  <div class="ls-particles ls-part-2"></div>
                  <div class="ls-particles ls-part-3"></div>
                  <div class="ls-particles ls-part-4"></div>
                  <div class="ls-particles ls-part-5"></div>
                  <div class="lightsaber ls-left ls-green"></div>
                  <div class="lightsaber ls-right ls-red"></div>
                </div>  

                <?php
            }
        }
        
      
      }
      mysqli_close($conexion);

?>

<script>
    setTimeout(() => {
    window.location.href='concesionaria.php';
    }, "7000");

  
</script>
</body>
</html>
