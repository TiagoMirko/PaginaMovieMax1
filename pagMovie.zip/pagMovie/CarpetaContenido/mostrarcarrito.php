<?php 
session_start();
  



$servername = "127.0.0.1";
$username = "alumno";
$password = "alumnoipm";
$database = "basededatosmoviemax3__";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = [
       
    ];
}

if (isset($_POST['eliminar_id'])) {
    foreach ($_SESSION['carrito'] as $index => $producto) {
        if ($producto['id'] == $_POST['eliminar_id']) {
            unset($_SESSION['carrito'][$index]);
            $_SESSION['carrito'] = array_values($_SESSION['carrito']); // Re-indexar el array
            break;
        }
    }
}

if (isset($_POST['pagar'])) {
    $_SESSION['carrito'] = []; 
   
    header("Location: confirmacion.php");
    exit();
}


$total = 0;
foreach ($_SESSION['carrito'] as $producto) {
    $total += isset($producto['precio']) ? $producto['precio'] : 0; // Aseguramos que 'precio' exista
}


$descuento = 0;
if (isset($_POST['cupon']) && $_POST['cupon'] === 'MOVIEMAX') {
    $descuento = $total * 0.3;
    $total -= $descuento;
}

$_SESSION['total_compra'] = $total;


?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Mi Carrito</title>
    <link rel="stylesheet" href="mostrarcarrito.css">
    <link rel="icon" href="PeliculaImagenes/logoPrincipio.png">
    <style>
        .checkout-container { display: flex; gap: 20px; }
        .summary-section { max-width: 300px; }
        .pay-button, .apply-coupon {
            background-color: #000;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .delete-btn{
            background-color: red;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .pay-button:hover, .apply-coupon:hover, .delete-btn:hover {
            background-color: #333;
            
        }
        .cart-items img { width: 50px; height: auto; }
        .cart-item { display: flex; gap: 10px; align-items: center; justify-content: space-between; }
        .total-section, .discount-section { margin-top: 20px; }
        .breadcrumb { display: flex; gap: 5px; margin-bottom: 20px; align-items: center; }
        .breadcrumb img { width: 50px; height: auto; }
        .breadcrumb a { color: #333; text-decoration: none; }
        .breadcrumb a:hover { text-decoration: underline; }
    </style>
</head>
<body>



<div class="checkout-container">
    <div class="info-section">
        <h1 class="header">Carrito de Compras</h1>
        <div class="breadcrumb">
    <div class="logo-container">
        <img src="PeliculaImagenes/Logo.png" alt="Logo" > <!-- Cambia a la ruta de tu logo -->
    </div>
    <div class="links-container">
        <a href="iniciosesion.php">Inicio de Sesión</a> >
        <a href="concesionaria.php">Movie Max </a> >
        <span>Carrito</span>
    </div>
</div>
        <h2>Información de contacto</h2>
        <input type="email"  id="email" placeholder="Correo electrónico" required>
        <div class="newsletter-checkbox">
            <input type="checkbox" id="newsletter" checked>
            <label for="newsletter">Enviarme novedades y ofertas por correo electrónico</label>
        </div>
        <form class="payment-form" action="confirmacion.php" method="post" onsubmit="return verificarTotal();">
    <h2>Dirección de envío</h2>
    <select name="pais" id="pais" required>
        <option value="">Seleccione País</option>
        <option>Argentina</option>
        <option>Chile</option>
        <option>Brazil</option>
        <option>Bolivia</option>
        <option>Uruguay</option>
        <option>Paraguay</option>
    </select>
    <input type="text"  id="nombre" placeholder="Nombre" required>
    <input type="text"  id="apellido" placeholder="Apellido" required>
    <input type="text"  id="direccion" placeholder="Calle y número de casa" required>

   
    <h2>Pago con tarjeta</h2>
    <input type="text" placeholder="Número de tarjeta"name="numeroTarjeta" class="card-number" required maxlength="19" pattern="\d{4}\s\d{4}\s\d{4}\s\d{4}">
    <div class="card-details">
        <input type="text" name="mes" placeholder="MM" class="card-expiry" required maxlength="2" pattern="\d{2}">
        <input type="text" name="año" placeholder="AA" class="card-expiry" required maxlength="2" pattern="\d{2}">
        <input type="text" name="cvc" placeholder="CVC" class="card-cvc" required maxlength="3" pattern="\d{3}">
    </div>
    <input type="text" name="nombreTarjeta" placeholder="Nombre en la tarjeta" class="card-name" required pattern="[a-zA-Z\s]+">

    
    <button type="submit" class="pay-button" name="pagar">Pagar $<?php echo number_format($total, 2); ?></button>
</form>
    </div>

    <div class="summary-section">
        <h2>Resumen del Pedido</h2>
        <?php if (isset($_SESSION['carrito']) && count($_SESSION['carrito']) > 0): ?>
            <div class="cart-items">
                <?php foreach ($_SESSION['carrito'] as $producto): ?>
                    <div class="cart-item">
                        <img  src="<?php echo $producto['img'] ?>" >
                        <div>
                            <p class="item-name"><?php echo $producto['nombre']; ?></p>
                            <p class="item-price">$<?php echo number_format($producto['precio'], 2); ?></p>
                        </div>
                        <form method="POST" action="">
                            <input type="hidden" name="eliminar_id" value="<?php echo $producto['id']; ?>">
                            <button type="submit" class="delete-btn" id="boton-elimiar">Eliminar</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            </div>

            
            <div class="total-section">
                <p class="subtotal">Subtotal: $<?php echo number_format($total + $descuento, 2); ?></p>

                
                <div class="discount-section">
            <h3>Aplicar cupón de descuento</h3>
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <input type="text" name="cupon" placeholder="Código de cupón">
                <button type="submit" class="apply-coupon">Aplicar cupón</button>
            </form>
            <?php if ($descuento > 0): ?>
                <p style="color: green;">Cupón aplicado: -$<?php echo number_format($descuento, 2); ?></p>
            <?php endif; ?>
        </div>

                <p class="total">Total: $<?php echo number_format($total, 2); ?></p>
            </div>
        <?php else: ?>
            <p>No hay productos en el carrito.</p>
        <?php endif; ?>
    </div>
</div>

<script>
function validarFormulario() {
    const requiredFields = document.querySelectorAll('.info-section input[required], .info-section select[required]');
    for (let field of requiredFields) {
        if (!field.value) {
            alert("Por favor, rellene todos los campos obligatorios.");
            return false;
        }
    }
    return true;
}


document.querySelector('.card-number').addEventListener('input', function (e) {
    let value = e.target.value.replace(/\D/g, '').substring(0, 16); // Limitar a 16 dígitos
    value = value.replace(/(\d{4})(?=\d)/g, '$1 '); // Insertar espacio cada 4 dígitos
    e.target.value = value;
});

document.querySelector('.card-name').addEventListener('input', function (e) {
    e.target.value = e.target.value.replace(/[^a-zA-Z\s]/g, ''); // Reemplazar todo lo que no sea letras o espacios
});

document.querySelectorAll('.card-expiry, .card-cvc').forEach(input => {
    input.addEventListener('input', (e) => {
        e.target.value = e.target.value.replace(/\D/g, ''); // Limitar a solo números
    });
});
</script>
<script>
function verificarTotal() {
    const total = <?php echo $total; ?>;
    if (total === 0) {
        alert("Debe agregar productos al carrito antes de proceder al pago.");
        return false; 
    }
    const email = document.getElementById('email').value;
    const pais = document.getElementById('pais').value;
    const nombre = document.getElementById('nombre').value;
    const apellido = document.getElementById('apellido').value;
    const direccion = document.getElementById('direccion').value;

    if (!email || !pais || !nombre || !apellido || !direccion) {
        alert("Por favor, complete toda la información de contacto y dirección de envío antes de proceder.");
        return false; 
    }
    return true; 
    }
</script>
</body>
</html>
