-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3307
-- Tiempo de generación: 19-11-2024 a las 01:30:11
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `basededatosmoviemax3`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pelicula`
--

CREATE TABLE `pelicula` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `fecha_lanzamiento` int(11) DEFAULT NULL,
  `duracion` time DEFAULT NULL,
  `acceso` enum('gratis','alquiler') DEFAULT NULL,
  `precio` decimal(4,2) DEFAULT NULL,
  `genero` varchar(45) DEFAULT NULL,
  `img` text NOT NULL,
  `restriccion_año` varchar(45) DEFAULT NULL,
  `informacion_audiencia` text DEFAULT NULL,
  `informacion_idioma` text DEFAULT NULL,
  `informacion_calidad` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pelicula`
--

INSERT INTO `pelicula` (`id`, `nombre`, `descripcion`, `fecha_lanzamiento`, `duracion`, `acceso`, `precio`, `genero`, `img`, `restriccion_año`, `informacion_audiencia`, `informacion_idioma`, `informacion_calidad`) VALUES
(1, 'Oppenheimer', 'Christopher Nolan dirige a Cillian Murphy en este aclamado drama biográfico sobre el físico J. Robert Oppenheimer, el padre de la bomba atómica.', 2023, '03:00:00', 'alquiler', 5.99, 'Drama', 'PeliculaImagenes/oppenheimer.jpg', '16', 'No recomendada para menores de 16 años', 'Inglés,Aleman, Polaco,Español, Francés, Italiano', 'SD, HD, UHD, HDR10, IMAX Enhanced'),
(2, 'Barbie', 'Vivir en Barbie Land consiste en ser un ser perfecto en un lugar perfecto. A menos que tengas una crisis existencial total. O seas un Ken.', 2023, '01:54:00', 'alquiler', 5.99, 'Comedia', 'PeliculaImagenes/barbie.jpg', 'TP', 'Apta para todos los públicos', 'Catalán, Inglés, Español, Ruso, Ucraniano, Alemán, Italiano, Francés, Checo, Húngaro, Polaco', 'SD, HD, UHD, HDR10'),
(3, 'Kung fu Panda', 'Cuando el último artilugio de Flint Lockwood (Bill Hader) destruye accidentalmente la plaza del pueblo y vuela hacia las nubes, este cree que su carrera de inventor está terminada. Entonces sucede algo inesperado cuando comienzan a llover deliciosas hamburguesas con queso del cielo.', 2024, '01:33:00', 'alquiler', 2.99, 'Comedia', 'PeliculaImagenes/kungfupanda4.jpg', 'TP', 'Apta para todos los públicos', 'Inglés, Español, Francés, Italiano', 'SD, HD, UHD, HDR10, IMAX Enhanced'),
(4, 'Que paso ayer', 'Unos días antes de su boda, Doug Billings y sus mejores hombres van a Las Vegas para una despedida de soltero. Sin embargo, al día siguiente, los amigos se dan cuenta de que no recuerdan la noche anterior.\n', 2009, '01:40:00', 'alquiler', 2.99, 'Comedia', 'PeliculaImagenes/qpa.jpg', '18', 'No recomendada para menores de 18 años', 'Español, Inglés', 'SD, HD'),
(6, 'Minions 2', 'Gru da la bienvenida a un nuevo miembro a la familia, Gru Jr., que tiene la intención de atormentar a su padre. Sin embargo, su pacífica existencia pronto se derrumba cuando el genio criminal Maxime Le Mal escapa de prisión y jura vengarse de Gru.', 2022, '01:28:00', 'alquiler', 1.99, 'Comedia', 'PeliculaImagenes/minions2.jpg', 'TP', 'Apta para todos los públicos', 'Español, Inglés, Alemán, Francés, Danés, Polaco, Rumano, Húngaro, Checo, Portugués, Italiano, Holandés / Flamenco', 'SD, HD, UHD, HDR10'),
(7, 'Proyecto X', '\nTres estudiantes de último año de secundaria deciden organizar una fiesta para ganar popularidad entre sus compañeros. Sin embargo, su plan pronto se vuelve inmanejable cuando rápidamente se divulga la noticia de su reunión.', 2012, '01:28:00', 'alquiler', 2.99, 'Comedia', 'PeliculaImagenes/project-x.jpg', '18', 'No recomendada para menores de 18 años', 'Español, Inglés', 'SD'),
(8, 'Super Bad', 'Dos mejores amigos de la secundaria deciden tener una fiesta memorable antes de despedirse e ir a diferentes universidades. Pero las cosas se complican y se meten en grandes problemas.', 2007, '01:59:00', 'alquiler', 1.99, 'Comedia', 'PeliculaImagenes/superBad.jpg', '18', 'No recomendada para menores de 18 años', 'Inglés, Español', 'SD, HD'),
(9, 'Shrek 4', '\nShrek, aburrido de su vida, quiere recuperar su gloria perdida. Hace un pacto con Rumpelstiltskin, mediante el cual este último engaña a Shrek enviándolo a un mundo donde él es el rey y los ogros son cazados.', 2010, '01:33:00', 'alquiler', 1.99, 'Comedia', 'PeliculaImagenes/Shrek4.jpg', 'TP', 'Apta para todos los públicos', 'Inglés, Italiano, Polaco, Español', 'SD, HD'),
(10, 'Anabelle', 'Judy y su niñera se quedan solas en su casa después de que sus padres se van a investigar un caso. Sin embargo, un invitado inesperado libera a Annabelle, desatando actividad demoníaca en la casa.', 2014, '01:39:00', 'alquiler', 2.99, 'Terror', 'PeliculaImagenes/anabelle.jpg', '16', 'No recomendada para menores de 16 años', 'Inglés, Español', 'SD, HD'),
(11, 'IT', 'Después de 27 años, el Losers Club recibe una llamada de su amigo Mike Hanlon informándole que Pennywise ha vuelto. Deciden cumplir su promesa y regresar a su antiguo pueblo para acabar para siempre con el malvado payaso.', 2019, '02:15:00', 'alquiler', 3.99, 'Terror', 'PeliculaImagenes/it2.jpg', '18', 'No recomendada para menores de 18 años', 'Checo, Inglés, Francés, Alemán, Húngaro, Italiano, Polaco, Español, Ucraniano', 'SD, HD, UHD, HDR10'),
(12, 'Smile', '\nDespués de presenciar un incidente extraño y traumático que involucra a un paciente, la Dra. Rose Cotter comienza a experimentar sucesos aterradores que no puede explicar. A medida que un terror abrumador comienza a apoderarse de su vida, Rose debe enfrentar su inquietante pasado para sobrevivir y escapar de su nueva y aterradora realidad.\n', 2022, '01:55:00', 'alquiler', 1.99, 'Terror', 'PeliculaImagenes/smile.jpg', '16', 'No recomendada para menores de 16 años\n', 'Inglés, Español', 'SD, HD'),
(13, 'El Conjuro', 'Rod y Carolyn encuentran a su perro muerto en circunstancias misteriosas y experimentan un espíritu que daña a su hija Andrea. Finalmente llaman a investigadores que pueden ayudarlos a salir del lío.', 2013, '01:52:00', 'alquiler', 3.99, 'Terror', 'PeliculaImagenes/elconjuro.jpg', '16', 'No recomendada para menores de 16 años', 'Inglés, Español', 'SD, HD'),
(14, 'REC', 'La presentadora de televisión nocturna Angela y su director de fotografía están siguiendo al servicio de bomberos en una llamada a un edificio de apartamentos, pero la policía española cierra el edificio después de que una anciana es infectada por un virus que le da una fuerza sobrehumana.', 2008, '01:18:00', 'alquiler', 1.99, 'Terror', 'PeliculaImagenes/rec.png', '18', 'No recomendada para menores de 18 años', 'Español', 'SD, HD'),
(15, 'Freddy Kruger', 'Después de que Kris y su novio Dean mueren debido a un sueño misterioso, Nancy, su amiga, que ha estado teniendo sueños similares, se da cuenta de que el asesino encuentra a sus víctimas cuando se quedan dormidas.\n', 2010, '01:35:00', 'alquiler', 2.99, 'Terror', 'PeliculaImagenes/Freddyjpg.jpg', '18', 'No recomendada para menores de 18 años', 'Inglés, Español', 'SD, HD'),
(16, 'Terrifier', 'Un payaso loco acecha e intenta matar a tres mujeres en un viejo y miserable edificio de apartamentos en la noche de Halloween.', 2018, '01:32:00', 'alquiler', 2.99, 'Terror', 'PeliculaImagenes/terrifier.jpg', '18', 'No recomendada para menores de 18 años\n', 'Español, Inglés', 'SD, HD'),
(17, 'John Wick 4', 'El marqués Vincent de Gramont pretende matar a John Wick para afianzar su poder en la Orden Suprema. Sin embargo, John tratará de adelantarse a cada uno de sus movimientos hasta lograr enfrentarse cara a cara con su peor enemigo.', 2023, '02:49:00', 'alquiler', 3.99, 'Accion', 'PeliculaImagenes/jw.jpg', '16', 'No recomendada para menores de 16 años\n', 'Inglés, Español', 'SD, HD, UHD, HDR10'),
(18, 'M. Imposible 7 ', 'Ethan debe detener a una inteligencia artificial que todas las potencias mundiales codician, la cual se ha vuelto tan poderosa que se rebeló contra sus creadores y ahora es una amenaza en sí misma.', 2023, '02:43:00', 'alquiler', 3.99, 'Accion', 'PeliculaImagenes/misimpos.jpg', '12', 'No recomendada para menores de 12 años', 'Francés, Polaco, Italiano, Ucraniano, Húngaro, Checo, Inglés, Español, Alemán', 'SD, HD, UHD, HDR10'),
(19, 'Fight Club', 'Un empleado de oficina insomne, harto de su vida, se cruza con un vendedor peculiar. Ambos crean un club de lucha clandestino como forma de terapia y, poco a poco, la organización crece y sus objetivos toman otro rumbo.', 1999, '02:19:00', 'alquiler', 1.99, 'Accion', 'PeliculaImagenes/fC.png', '18', 'No recomendada para menores de 18 años', 'Inglés, Italiano, Francés, Polaco, Ruso, Español', 'SD, HD'),
(20, 'Seven', 'El veterano teniente Somerset está a punto de jubilarse y ser reemplazado por el impulsivo detective David Mills. Ambos tendrán que colaborar en la resolución de unos asesinatos cometidos por un psicópata que se basa en los siete pecados capitales.', 1996, '02:07:00', 'alquiler', 2.99, 'Accion', 'PeliculaImagenes/Seven.png', '18', 'No recomendada para menores de 18 años', 'Inglés, Español', 'SD'),
(21, 'Fast and Furius ', 'Motivado por su sed de venganza, el hijo del narcotraficante Hernán Reyes pone a Dom Toretto y a toda su familia en el punto de mira. Aunque en el pasado Dom y compañía fueron capaces de salir victoriosos de misiones casi imposibles, esta vez la amenaza sobre ellos luce implacable y dispuesta a saldar cuentas sin importar las consecuencias.', 2023, '02:21:00', 'alquiler', 3.99, 'Accion', 'PeliculaImagenes/rapidosyfuriosos.jpg', '12', 'No recomendada para menores de 12 años', 'Inglés, Polaco, Húngaro, Ucraniano, Checo, Español, Francés, Alemán, Italiano', 'SD, HD, UHD, HDR10'),
(22, 'Mad Max', 'En un mundo apocalíptico, un tirano gobierna un desierto inhóspito y controla cada gota de agua. Dos rebeldes, uno que escapa del dolor y el otro que se acerca a su infancia, son la última esperanza para unos pocos.', 2015, '02:00:00', 'alquiler', 3.99, 'Accion', 'PeliculaImagenes/madmax.jpg', '16', 'No recomendada para menores de 16 años', 'Inglés, Polaco, Checo, Húngaro, Ucraniano, Español', 'SD, HD, UHD, HDR10, HDR10+'),
(23, 'The Batman', 'En su segundo año luchando contra el crimen, Batman explora la corrupción existente en la ciudad de Gotham y el vínculo de esta con su propia familia. Además, entrará en conflicto con un asesino en serie conocido como \'el Acertijo\'.', 2022, '02:56:00', 'alquiler', 2.99, 'Accion', 'PeliculaImagenes/batman.jpeg', '12', 'No recomendada para menores de 12 años', 'Inglés, Español', 'SD, HD, UHD, HDR10, HDR10+'),
(24, 'Venom', 'Después de encontrar un cuerpo anfitrión en el periodista de investigación Eddie Brock, el simbionte alienígena debe enfrentarse a un nuevo enemigo, Carnage, el alter ego del asesino en serie Cletus Kasady.', 2021, '01:37:00', 'alquiler', 2.99, 'Ciencia Ficcion', 'PeliculaImagenes/venom23.jpg', '18', 'No recomendada para menores de 18 años', 'Inglés, Polaco, Español, Francés, Italiano', 'SD, HD, UHD, HDR10, IMAX Enhanced'),
(25, 'Spider-Man 3', 'Peter Parker sufre una terrible transformación cuando su traje se vuelve negro y libera su personalidad oscura y vengativa. Afrontará el mayor desafío de su vida al tener que redescubrir la humildad y compasión que lo hacen ser quien es: un héroe.', 2007, '02:19:00', 'alquiler', 2.99, 'Ciencia Ficcion', 'PeliculaImagenes/spiderman3B.jpg', '7', 'No recomendada para menores de 7 años', 'Inglés, Polaco, Italiano, Alemán, Francés, Español', 'SD, HD, UHD, HDR10'),
(26, 'Avengers 4', 'Después de los eventos devastadores de \'Avengers: Infinity War\', el universo está en ruinas debido a las acciones de Thanos, el Titán Loco. Con la ayuda de los aliados que quedaron, los Vengadores deberán reunirse una vez más para intentar detenerlo y restaurar el orden en el universo de una vez por todas.', 2019, '03:01:00', 'alquiler', 3.99, 'Ciencia Ficcion', 'PeliculaImagenes/avengers.jpg', '7', 'No recomendada para menores de 7 años', 'Inglés, Español', 'SD, HD'),
(27, 'El Hobbit', '\n\nSe convence a Bilbo Bolsón, un hobbit, para que acompañe al mago Gandalf y a un grupo de enanos en un viaje para recuperar la ciudad enana de Erebor y todas sus riquezas del dragón Smaug.', 2012, '01:42:00', 'alquiler', 1.99, 'Ciencia Ficcion', 'PeliculaImagenes/hobbit.jpg', '7', 'No recomendada para menores de 7 años', 'Español, Inglés', 'SD, HD'),
(28, 'Deadpool 3', 'Lobezno se recupera de sus heridas cuando se cruza con el bocazas, Deadpool, que ha viajado en el tiempo para curarlo con la esperanza de hacerse amigos y formar un equipo para acabar con un enemigo común.', 2024, '02:07:00', 'alquiler', 4.99, 'Ciencia Ficcion', 'PeliculaImagenes/deadpoolwolv.jpg', '18', 'No recomendada para menores de 18 años', 'Español, Inglés', 'SD, HD'),
(29, 'Blade Runner ', 'Treinta años después de los eventos del primer film, un nuevo blade runner, K (Ryan Gosling) descubre un secreto largamente oculto que podría acabar con el caos que impera en la sociedad. El descubrimiento de K le lleva a iniciar una búsqueda de Rick Deckard (Harrison Ford), un blade runner al que se le perdió la pista hace 30 años.', 2017, '02:43:00', 'alquiler', 2.99, 'Ciencia Ficcion', 'PeliculaImagenes/bladerunner.png', '18', 'No recomendada para menores de 18 años', 'Inglés, Polaco, Ucraniano, Alemán, Español', 'SD, HD, UHD, HDR10, IMAX Enhanced'),
(30, 'Matrix', 'El programador informático Thomas Anderson, más conocido en el mundo de los \'hacker\' como Neo, está en el punto de mira del temible agente Smith. Otros dos piratas informáticos, Trinity y Morfeo, se ponen en contacto con Neo para ayudarlo a escapar. Matrix te posee. Sigue al conejo blanco.', 1999, '02:16:00', 'alquiler', 2.99, 'Ciencia Ficcion', 'PeliculaImagenes/matrix.jpg', '18', 'No recomendada para menores de 18 años', 'Inglés, Checo, Polaco, Ucraniano, Húngaro', 'SD, HD, UHD, HDR10'),
(31, 'Lo imposible', 'María, Henry y sus tres hijos pequeños vuelan desde Japón a Tailandia para pasar las vacaciones de Navidad en la playa. La mañana después de Navidad, mientras se bañan en la piscina, un tsunami colosal destroza el hotel y gran parte de la costa del sudeste asiático. La familia tendrá que luchar para sobrevivir y reencontrarse.', 2013, '01:54:00', 'alquiler', 2.99, 'Drama', 'PeliculaImagenes/loIMPOSIBLE.jpg', '12', 'No recomendada para menores de 12 años', 'Inglés, Español', 'SD, HD'),
(32, 'The whale', 'Un solitario profesor de inglés que tiene obesidad mórbida y vive recluido intenta reconectar con su hija adolescente para tener una última oportunidad de redención.', 2022, '01:57:00', 'alquiler', 3.99, 'Drama', 'PeliculaImagenes/whale.jpg', '16', 'No recomendada para menores de 16 años', 'Inglés, Español', 'SD, HD'),
(33, 'EL Pianista', '\nDurante la Segunda Guerra Mundial, el aclamado músico polaco Wladyslaw se enfrenta a varias luchas mientras pierde el contacto con su familia. A medida que la situación empeora, se esconde en las ruinas de Varsovia para sobrevivir.', 2003, '02:30:00', 'alquiler', 1.99, 'Drama', 'PeliculaImagenes/elpianista.jpg', '13', 'No recomendada para menores de 13 años', 'Español, Inglés', 'SD, HD\n'),
(34, 'Titanic', '\nRose, que se ve obligada a casarse con un hombre rico, se enamora de Jack, un artista talentoso, a bordo del insumergible Titanic. Desafortunadamente, el barco choca contra un iceberg, poniendo en peligro sus vidas.', 1998, '03:14:00', 'alquiler', 1.99, 'Drama', 'PeliculaImagenes/titanic.jpg', '13', 'No recomendada para menores de 13 años', 'Español, Inglés, Francés, Alemán, Italiano', 'SD, HD'),
(36, 'Interestellar', 'Un grupo de científicos y exploradores, encabezados por Cooper, se embarcan en un viaje espacial para encontrar un lugar con las condiciones necesarias para reemplazar a la Tierra y comenzar una nueva vida allí. La Tierra está llegando a su fin y este grupo necesita encontrar un planeta más allá de nuestra galaxia que garantice el futuro de la raza humana.', 2014, '02:49:00', 'alquiler', 2.99, 'Drama', 'PeliculaImagenes/interestellar1.jpg', '12', 'No recomendada para menores de 12 años', 'Inglés, Ucraniano, Polaco, Checo, Húngaro, Español, Francés, Alemán, Italiano\n', 'SD, HD, UHD, HDR10\n'),
(37, 'Joker 2', 'Luchando con su doble identidad, el comediante fracasado Arthur Fleck conoce al amor de su vida, Harley Quinn, mientras está encarcelado en el Hospital Estatal de Arkham.', 2024, '02:19:00', 'alquiler', 5.99, 'Drama', 'PeliculaImagenes/joker2.jpg', '18', 'No recomendada para menores de 18 años', 'Inglés, Alemán, Checo, Polaco, Español.', 'SD, HD, UHD, HDR10');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tarjeta`
--

CREATE TABLE `tarjeta` (
  `idTarjeta` int(11) NOT NULL,
  `numeroTarjeta` varchar(45) CHARACTER SET armscii8 COLLATE armscii8_bin NOT NULL DEFAULT 'NOT NULL',
  `mes` int(11) NOT NULL,
  `año` int(11) NOT NULL,
  `cvc` int(11) NOT NULL,
  `nombreTarjeta` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tarjeta`
--

INSERT INTO `tarjeta` (`idTarjeta`, `numeroTarjeta`, `mes`, `año`, `cvc`, `nombreTarjeta`) VALUES
(1, '1231 2222 2222 2222', 23, 31, 312, 'dsadasd'),
(2, '1231 2222 2222 2222', 23, 31, 312, 'dsadasd'),
(3, '1231 2222 2222 2222', 23, 31, 312, 'dsadasd'),
(4, '2222 2222 2131 3131', 12, 31, 312, 'DASDASSS'),
(5, '2222 2222 2131 3131', 12, 31, 312, 'DASDASSS');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `Usuario` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `contraseña` varchar(45) NOT NULL,
  `fecha` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `Usuario`, `email`, `fecha_nacimiento`, `contraseña`, `fecha`) VALUES
(1, 'AlumnoIPM', 'alumno26.tiago@ipm.edu.ar', '2024-09-12', 'alumnoipm', '2002-10-25'),
(2, 'tiago', 'tis@08', '2024-11-17', '3434', '2024-11-13');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `pelicula`
--
ALTER TABLE `pelicula`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tarjeta`
--
ALTER TABLE `tarjeta`
  ADD PRIMARY KEY (`idTarjeta`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `pelicula`
--
ALTER TABLE `pelicula`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT de la tabla `tarjeta`
--
ALTER TABLE `tarjeta`
  MODIFY `idTarjeta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
