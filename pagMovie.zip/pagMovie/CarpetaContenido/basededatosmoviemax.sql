-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3307
-- Tiempo de generación: 28-10-2024 a las 03:39:00
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `basededatosmoviemax`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pelicula`
--

CREATE TABLE `pelicula` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `fecha_lanzamiento` date DEFAULT NULL,
  `duracion` time DEFAULT NULL,
  `acceso` enum('gratis','alquiler') DEFAULT NULL,
  `precio` decimal(4,2) DEFAULT NULL,
  `genero` varchar(45) DEFAULT NULL,
  `img` varchar(45) NOT NULL, 
  `restriccion_año` varchar(45),
  `informacion_audiencia` text ,
  `informacion_idioma` text,
  `informacion_calidad` text 
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pelicula`
--


INSERT INTO `pelicula` VALUES (1,'Oppenheimer','Christopher Nolan dirige a Cillian Murphy en este aclamado drama biográfico sobre el físico J. Robert Oppenheimer, el padre de la bomba atómica.','2023-07-21','03:00:00','gratis',NULL,'Accion','PeliculaImagenes/oppenheimer.jpg','16+','La clasificación R indica que Oppenheimer tiene contenido restringido y no es apta para menores de 16 años sin acompañamiento. ','Inglés,Aleman, Polaco,Español, Francés, Italiano','SD, HD, UHD, HDR10, IMAX Enhanced'),(2,'Barbie','Vivir en Barbie Land consiste en ser un ser perfecto en un lugar perfecto. A menos que tengas una crisis existencial total. O seas un Ken.','2023-07-21','01:54:00','gratis',NULL,'Comedia','PeliculaImagenes/barbie.jpg','ATP','Apta para todos los públicos','Catalán, Inglés, Español, Ruso, Ucraniano, Alemán, Italiano, Francés, Checo, Húngaro, Polaco','SD, HD, UHD, HDR10'),(3,'Lluvia de hamburguesas','Cuando el último artilugio de Flint Lockwood (Bill Hader) destruye accidentalmente la plaza del pueblo y vuela hacia las nubes, este cree que su carrera de inventor está terminada. Entonces sucede algo inesperado cuando comienzan a llover deliciosas hamburguesas con queso del cielo.','2009-10-01','01:30:00','alquiler',2.99,'Comedia','PeliculaImagenes/lluviadehamburguesa.jpg','7+','La clasificación R indica que Lluvia de hamburguesas tiene contenido restringido y no es apta para menores de 7 años sin acompañamiento. ','Inglés, Español, Francés, Italiano','SD, HD, UHD, HDR10, IMAX Enhanced'),(4,'¿Que paso ayer?','Dos días antes de su boda, Doug y tres amigos viajan a Las Vegas para una despedida de soltero memorable y salvaje. De hecho, cuando los tres padrinos de boda se despiertan a la mañana siguiente, no recuerdan nada; ni pueden encontrar a Doug. Con poco tiempo de sobra, los tres confusos amigos intentan volver sobre sus pasos y encontrar a Doug para poder llevarlo de regreso a Los Ángeles a tiempo para caminar hacia el altar.','2009-08-10','01:40:00','alquiler',2.99,'Comedia','PeliculaImagenes/qpa.jpg','18+','No recomendada para menores de 18 años','Español, Inglés','SD, HD'),(5,'El show de Truman','Él no lo sabe, pero todo en la vida de Truman Burbank es parte de un enorme televisor. El productor ejecutivo Christof organiza The Truman Show, una transmisión en vivo de cada movimiento de Truman capturado por cámaras ocultas. Cristof intenta controlar la mente de Truman, incluso eliminando a su verdadero amor, Sylvia (Natascha McElhone), del programa y reemplazándola con Meryl. Sin embargo, a medida que Truman descubre gradualmente la verdad, debe decidir si actúa en consecuencia.','1998-10-22','01:43:00','alquiler',3.99,'Comedia','PeliculaImagenes/sDT.png','ATP','Apta para todos los públicos','Inglés, Español','SD'),(6,'Mi villano favorito 4 ','Gru da la bienvenida a un nuevo miembro a la familia, Gru Jr., que tiene la intención de atormentar a su padre. Sin embargo, su pacífica existencia pronto se derrumba cuando el genio criminal Maxime Le Mal escapa de prisión y jura vengarse de Gru.','2024-06-20','01:34:00','alquiler',4.99,'Comedia','PeliculaImagenes/mivillanofav.jpg','ATP','Apta para todos los públicos','Español, Inglés, Alemán, Francés, Danés, Polaco, Rumano, Húngaro, Checo, Portugués, Italiano, Holandés / Flamenco','SD, HD, UHD, HDR10'),(7,'Proyecto X','Thomas , Costa  y JB  son tres estudiantes de último año de secundaria que están decididos a dejar su huella. Pero, ¿cómo hacerse inolvidables en los anales de la historia de la escuela secundaria? ¡Con una fiesta épica, por supuesto! La idea es bastante inocente, pero nada podría preparar a los tres amigos para esta fiesta. A medida que se corre la voz de lo genial de la velada, los sueños se arruinan, los récords se manchan y nacen leyendas.','2012-03-15','01:28:00','alquiler',2.99,'Comedia','PeliculaImagenes/project-x.jpg','18+','No recomendada para menores de 18 años','Español, Inglés','SD'),(8,'El lobo de Wall Street','En 1987, Jordan Belfort acepta un trabajo de nivel básico en una firma de corretaje de Wall Street. A principios de los años 90, cuando todavía tenía 20 años, Belfort funda su propia firma, Stratton Oakmont. Junto con su lugarteniente de confianza y un alegre grupo de corredores, Belfort hace una enorme fortuna estafando a inversores ricos por millones. Sin embargo, mientras Belfort y sus compinches participan en una mezcla hedonista de sexo, drogas y emociones, la SEC y el FBI se acercan a su imperio de excesos.','2014-01-02','03:00:00','alquiler',3.99,'Comedia','PeliculaImagenes/elLOBOWS.jpeg','16+','No recomendada para menores de 16 años','Inglés, Español','SD, HD'),(9,'Son como niños','Un hombre soltero que bebe demasiado. Un padre con tres hijas a las que rara vez ve. Un tipo con sobrepeso y desempleado. Un amo de casa dominado por sus mujeres. Una exitosa agente de Hollywood casada con una diseñadora de moda. ¿Qué tienen en común estos cinco hombres? Solían jugar en el mismo equipo de baloncesto en la escuela. Ahora su ex entrenador ha muerto y se reencuentran en su funeral. ¿El grupo redescubrirá viejos vínculos?','2010-07-22','01:42:00','alquiler',2.99,'Comedia','PeliculaImagenes/soncomoñiños.jpg','ATP','Apta para todos los públicos','Inglés, Italiano, Polaco, Español','SD, HD'),(10,'Anabelle','John Form cree que ha encontrado el regalo perfecto para su futura esposa, Mia : una muñeca antigua con un hermoso vestido blanco. Sin embargo, el deleite de la pareja no dura mucho: una noche terrible, los adoradores del diablo invaden su casa y lanzan un violento ataque contra la pareja. Cuando los cultistas intentan invocar a un demonio, untan una runa sangrienta en la pared de la habitación del bebé y gotean sangre sobre la muñeca de Mia, convirtiendo así el antiguo objeto de belleza en un conducto para el mal supremo.','2014-10-23','01:39:00','alquiler',2.99,'Terror','PeliculaImagenes/anabelle.jpg','16+','No recomendada para menores de 16 años','Inglés, Español','SD, HD'),(11,'IT','Siete jóvenes marginados de Derry, Maine, están a punto de enfrentarse a su peor pesadilla: un antiguo mal que cambia de forma y emerge de las alcantarillas cada 27 años para atacar a los niños del pueblo. Los amigos se unen durante un verano aterrador y deben superar sus propios miedos personales para luchar contra el payaso asesino y sediento de sangre conocido como Pennywise.','2017-09-21','02:15:00','alquiler',3.99,'Terror','PeliculaImagenes/it.jpeg','16+','No recomendada para menores de 16 años','Checo, Inglés, Francés, Alemán, Húngaro, Italiano, Polaco, Español, Ucraniano','SD, HD, UHD, HDR10'),(12,'La masacre de Texas','Los influencers que quieren revitalizar un pueblo desierto de Texas se enfrentan al infame asesino en serie Leatherface, que oculta su rostro bajo una máscara de piel humana.','2022-02-18','01:23:00','alquiler',2.99,'Terror','PeliculaImagenes/met.jpg','18+','No recomendada para menores de 18 años\n','Inglés, Español','SD, HD'),(13,'El Conjuro','En 1970, los investigadores paranormales y demonólogos Lorraine y Ed Warren son convocados a la casa de Carolyn y Roger Perron. Los Perron y sus cinco hijas se han mudado recientemente a una granja aislada, donde una presencia sobrenatural se ha hecho notar. Aunque las manifestaciones son relativamente benignas al principio, los eventos pronto se intensifican de manera horrorosa, especialmente después de que los Warren descubren la macabra historia de la casa.','2013-08-08','01:52:00','alquiler',3.99,'Terror','PeliculaImagenes/elconjuro.jpg','16+','No recomendada para menores de 16 años','Inglés, Español','SD, HD'),(14,'REC','La presentadora de televisión nocturna Angela y su director de fotografía están siguiendo al servicio de bomberos en una llamada a un edificio de apartamentos, pero la policía española cierra el edificio después de que una anciana es infectada por un virus que le da una fuerza sobrehumana.','2008-09-11','01:18:00','alquiler',1.99,'Terror','PeliculaImagenes/rec.png','18+','No recomendada para menores de 18 años','Español','SD, HD'),(15,'El silencio de los inocentes','Jodie Foster interpreta a Clarice Starling, una de las mejores estudiantes de la academia de entrenamiento del FBI. Jack Crawford quiere que Clarice entreviste al Dr. Hannibal Lecter , un brillante psiquiatra que también es un psicópata violento, que cumple cadena perpetua por varios actos de asesinato y canibalismo. Crawford cree que Lecter puede tener información sobre un caso y que Starling, como una joven atractiva, puede ser el cebo para atraerlo.','1991-06-06','01:58:00','alquiler',2.99,'Terror','PeliculaImagenes/terror.png','18+','No recomendada para menores de 18 años','Inglés, Español','SD, HD'),(16,'Terrifier','Un payaso loco acecha e intenta matar a tres mujeres en un viejo y miserable edificio de apartamentos en la noche de Halloween.','2018-03-15','01:32:00','alquiler',2.99,'Terror','PeliculaImagenes/terrifier.jpg','18+','No recomendada para menores de 18 años\n','Español, Inglés','SD, HD'),(17,'John Wick 4','El marqués Vincent de Gramont pretende matar a John Wick para afianzar su poder en la Orden Suprema. Sin embargo, John tratará de adelantarse a cada uno de sus movimientos hasta lograr enfrentarse cara a cara con su peor enemigo.','2023-03-24','02:49:00','alquiler',3.99,'Accion','PeliculaImagenes/jw.jpg','16+','No recomendada para menores de 16 años\n','Inglés, Español','SD, HD, UHD, HDR10'),(18,'Mision Imposible 7 ','Ethan debe detener a una inteligencia artificial que todas las potencias mundiales codician, la cual se ha vuelto tan poderosa que se rebeló contra sus creadores y ahora es una amenaza en sí misma.','2023-07-12','02:43:00','alquiler',3.99,'Accion','PeliculaImagenes/misimpos.jpg','12+','No recomendada para menores de 12 años','Francés, Polaco, Italiano, Ucraniano, Húngaro, Checo, Inglés, Español, Alemán','SD, HD, UHD, HDR10'),(19,'El club de la pelea','Un empleado de oficina insomne, harto de su vida, se cruza con un vendedor peculiar. Ambos crean un club de lucha clandestino como forma de terapia y, poco a poco, la organización crece y sus objetivos toman otro rumbo.','1999-11-04','02:19:00','alquiler',1.99,'Accion','PeliculaImagenes/fC.png','18+','No recomendada para menores de 18 años','Inglés, Italiano, Francés, Polaco, Ruso, Español','SD, HD'),(20,'Seven','El veterano teniente Somerset está a punto de jubilarse y ser reemplazado por el impulsivo detective David Mills. Ambos tendrán que colaborar en la resolución de unos asesinatos cometidos por un psicópata que se basa en los siete pecados capitales.','1996-02-15','02:07:00','alquiler',2.99,'Accion','PeliculaImagenes/Seven.png','18+','No recomendada para menores de 18 años','Inglés, Español','SD'),(21,'Rápidos y furiosos 10','Motivado por su sed de venganza, el hijo del narcotraficante Hernán Reyes pone a Dom Toretto y a toda su familia en el punto de mira. Aunque en el pasado Dom y compañía fueron capaces de salir victoriosos de misiones casi imposibles, esta vez la amenaza sobre ellos luce implacable y dispuesta a saldar cuentas sin importar las consecuencias.','2023-05-19','02:21:00','alquiler',3.99,'Accion','PeliculaImagenes/rapidosyfuriosos.jpeg','12+','No recomendada para menores de 12 años','Inglés, Polaco, Húngaro, Ucraniano, Checo, Español, Francés, Alemán, Italiano','SD, HD, UHD, HDR10'),(22,'Mad Max','Un policía de carreteras vive entre el trabajo y una tranquila vida familiar, con su esposa y su bebé. Hasta que una pandilla de motorizados asesina a su familia. Desde ese momento, el policía vivirá para la venganza','1982-02-04','01:33:00','alquiler',1.99,'Accion','PeliculaImagenes/madmax.jpg',NULL,NULL,NULL,NULL),(23,'The Batman','En su segundo año luchando contra el crimen, Batman explora la corrupción existente en la ciudad de Gotham y el vínculo de esta con su propia familia. Además, entrará en conflicto con un asesino en serie conocido como \'el Acertijo\'.','2022-03-04','02:56:00','alquiler',2.99,'Accion','PeliculaImagenes/batman.jpeg',NULL,NULL,NULL,NULL),(24,'Venom','Después de encontrar un cuerpo anfitrión en el periodista de investigación Eddie Brock, el simbionte alienígena debe enfrentarse a un nuevo enemigo, Carnage, el alter ego del asesino en serie Cletus Kasady.','2021-10-01','01:37:00','alquiler',2.99,'Ciencia Ficcion','PeliculaImagenes/venom23.jpg','18','No recomendada para menores de 18 años','Inglés, Polaco, Español, Francés, Italiano','SD, HD, UHD, HDR10, IMAX Enhanced'),(25,'Spider-Man 3','Peter Parker sufre una terrible transformación cuando su traje se vuelve negro y libera su personalidad oscura y vengativa. Afrontará el mayor desafío de su vida al tener que redescubrir la humildad y compasión que lo hacen ser quien es: un héroe.','2007-05-03','02:19:00','alquiler',2.99,'Ciencia Ficcion','PeliculaImagenes/spiderman3B.jpg',NULL,NULL,NULL,NULL),(26,'Avengers: End game','Después de los eventos devastadores de \'Avengers: Infinity War\', el universo está en ruinas debido a las acciones de Thanos, el Titán Loco. Con la ayuda de los aliados que quedaron, los Vengadores deberán reunirse una vez más para intentar detenerlo y restaurar el orden en el universo de una vez por todas.','2019-04-26','03:01:00','alquiler',3.99,'Ciencia Ficcion','PeliculaImagenes/avengers.jpg',NULL,NULL,NULL,NULL),(27,'El Hobbit','Bilbo Bolsón lleva una vida sencilla con sus compañeros hobbits en la comarca, hasta que el mago Gandalf llega y lo convence de unirse a un grupo de enanos para recuperar el reino de Erebor. El viaje lleva a Bilbo en un camino a través de tierras peligrosas llenas de orcos, goblins y otras amenazas, además de su encuentro con Gollum y un sencillo anillo de oro que está unido al destino de la Tierra Media de una forma que Bilbo no puede imaginarse.','2012-12-13','01:42:00','alquiler',1.99,'Ciencia Ficcion','PeliculaImagenes/hobbit.jpg',NULL,NULL,NULL,NULL),(28,'Deadpool 3','Lobezno se recupera de sus heridas cuando se cruza con el bocazas, Deadpool, que ha viajado en el tiempo para curarlo con la esperanza de hacerse amigos y formar un equipo para acabar con un enemigo común.','2024-07-25','02:07:00','alquiler',4.99,'Ciencia Ficcion','PeliculaImagenes/deadpoolwolv.jpg',NULL,NULL,NULL,NULL),(29,'Blade Runner 2049','Tras la rebelión de los replicantes creados por bioingeniería para ser utilizados como mano de obra esclava y la prohibición a Tyrell Corporation de seguir con su fabricación, el empresario Niander Wallace adquirió lo que quedaba de Tyrell Corp. y creó una nueva línea de replicantes mucho más obedientes. Ahora, en el año 2049, los viejos modelos Nexus 8 que continúan con vida están siendo retirados. Los que les persiguen aún reciben el nombre de Blade Runner.','2017-10-05','02:43:00','alquiler',2.99,'Ciencia Ficcion','PeliculaImagenes/bladerunner.png',NULL,NULL,NULL,NULL),(30,'Matrix','El programador informático Thomas Anderson, más conocido en el mundo de los \'hacker\' como Neo, está en el punto de mira del temible agente Smith. Otros dos piratas informáticos, Trinity y Morfeo, se ponen en contacto con Neo para ayudarlo a escapar. Matrix te posee. Sigue al conejo blanco.','1999-06-10','02:16:00','alquiler',2.99,'Ciencia Ficcion','PeliculaImagenes/matrix.jpg',NULL,NULL,NULL,NULL),(31,'Lo imposible','María, Henry y sus tres hijos pequeños vuelan desde Japón a Tailandia para pasar las vacaciones de Navidad en la playa. La mañana después de Navidad, mientras se bañan en la piscina, un tsunami colosal destroza el hotel y gran parte de la costa del sudeste asiático. La familia tendrá que luchar para sobrevivir y reencontrarse.','2013-01-03','01:54:00','alquiler',2.99,'Drama','PeliculaImagenes/loIMPOSIBLE.jpg',NULL,NULL,NULL,NULL),(32,'The whale','Un solitario profesor de inglés que tiene obesidad mórbida y vive recluido intenta reconectar con su hija adolescente para tener una última oportunidad de redención.','2022-12-09','01:57:00','alquiler',1.99,'Drama','PeliculaImagenes/whale.jpg',NULL,NULL,NULL,NULL),(33,'EL pianista','Wladyslaw Szpilman, un brillante pianista polaco de origen judío, vive con su familia en el ghetto de Varsovia. Cuando, en 1939, los alemanes invaden Polonia, consigue evitar la deportación gracias a la ayuda de algunos amigos. Pero tendrá que vivir escondido y completamente aislado durante mucho tiempo, y para sobrevivir tendrá que afrontar constantes peligros.','2003-03-06','02:30:00','alquiler',2.99,'Drama','PeliculaImagenes/Elpianista.jpg',NULL,NULL,NULL,NULL),(34,'Argentina 1985','Argentina, 1985 está inspirada en la historia real de Julio Strassera, Luis Moreno Ocampo y su joven equipo jurídico que se atrevieron a acusar, contra viento y marea, a contrarreloj y bajo constante amenaza, a la más sangrienta dictadura militar argentina. Una batalla de David contra Goliat, con los héroes menos esperados.','2022-09-29','02:20:00','alquiler',2.99,'Drama','PeliculaImagenes/ARG198.jpeg',NULL,NULL,NULL,NULL),(35,'Sin novedad en el frente','En la Alemania de 1917, durante el estallido de la Primera Guerra Mundial, un joven con fuertes convicciones nacionalistas se alista en el ejército. El nuevo recluta, junto con la mayoría de su clase, es enviado al frente occidental y durante su participación en el conflicto bélico, sufre fuertes traumas y vive aterrorizado con la idea de morir en tierra de nadie.','2022-09-29','02:27:00','alquiler',3.99,'Drama','PeliculaImagenes/sinNovedadEnelFrente.jpg',NULL,NULL,NULL,NULL),(36,'Interestellar','Un grupo de científicos y exploradores, encabezados por Cooper, se embarcan en un viaje espacial para encontrar un lugar con las condiciones necesarias para reemplazar a la Tierra y comenzar una nueva vida allí. La Tierra está llegando a su fin y este grupo necesita encontrar un planeta más allá de nuestra galaxia que garantice el futuro de la raza humana.','2014-11-06','02:49:00','alquiler',2.99,'Drama','PeliculaImagenes/interestellar.jpg',NULL,NULL,NULL,NULL),(37,'Joker 2','','2024-10-03','02:19:00','alquiler',5.99,'Drama','PeliculaImagenes/joker (1).jpg',NULL,NULL,NULL,NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `Usuario` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `contraseña` varchar(45) NOT NULL,
  `fecha` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `Usuario`, `email`, `fecha_nacimiento`, `contraseña`, `fecha`) VALUES
(1, 'AlumnoIPM', 'alumno26.tiago@ipm.edu.ar', '2024-09-12', 'alumnoipm', '2002-10-25');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `pelicula`
--
ALTER TABLE `pelicula`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `pelicula`
--
ALTER TABLE `pelicula`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
