<?php
session_start();

$numeroTarjeta = $_POST["numeroTarjeta"];
$mes = $_POST["mes"];
$año = $_POST["año"];
$cvc = $_POST["cvc"];
$nombreTarjeta = $_POST["nombreTarjeta"];
$_SESSION["numeroTarjeta"] = $numeroTarjeta;





$servername = "127.0.0.1";
$username = "alumno";
$password = "alumnoipm";

$database1 = "basededatosmoviemax3_";
$conexion1 = mysqli_connect($servername, $username, $password, $database1);
if (!$numeroTarjeta) {
    die("El número de tarjeta no se ha enviado correctamente.");
}
if (!$conexion1) {
    die("Conexión fallida: " . mysqli_connect_error());
} else {
    $query1 = "INSERT INTO tarjeta VALUES (null, '$numeroTarjeta',  '$mes', '$año', '$cvc', '$nombreTarjeta')";
    $resultado1 = mysqli_query($conexion1, $query1);
}

mysqli_close($conexion1);


$database2 = "basededatosmoviemax3_";
$conexion2 = mysqli_connect($servername, $username, $password, $database2);

if (!$conexion2) {
    die("Conexión fallida a la base de datos de tarjeta: " . mysqli_connect_error());
} else {
    $query2 = "INSERT INTO tarjeta  VALUES (null,'$numeroTarjeta', '$mes', '$año', '$cvc', '$nombreTarjeta');";
    $resultado2 = mysqli_query($conexion2, $query2);
}

mysqli_close($conexion2);
?>
<!DOCTYPE html>
<link rel="icon" href="PeliculaImagenes/logoPrincipio.png">
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Compra Realizada</title>
    <style>
        
        body {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
            background-color: #4CAF50; 
            color: #fff;
            font-family: Arial, sans-serif;
        }

        .confirmation-container {
            text-align: center;
            position: relative;
        }

        
        .circle {
            width: 150px;
            height: 150px;
            background-color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            opacity: 0;
            animation: fadeIn 1s forwards, scaleIn 1.5s ease-in-out forwards;
        }

        
        .checkmark {
            width: 60px;
            height: 30px;
            border-bottom: 10px solid #4CAF50;
            border-left: 10px solid #4CAF50;
            transform: rotate(-45deg);
            opacity: 0;
            animation: fadeInCheck 1.5s 1s forwards;
        }

       
        .confirmation-text {
            font-size: 24px;
            margin-top: 20px;
            opacity: 0;
            animation: fadeInText 2s 1.5s forwards;
        }

   
        @keyframes fadeIn {
            to { opacity: 1; }
        }

        @keyframes scaleIn {
            0% { transform: scale(0.5); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }

        @keyframes fadeInCheck {
            to { opacity: 1; }
        }

        @keyframes fadeInText {
            to { opacity: 1; }
        }
    </style>
</head>
<body>
    <div class="confirmation-container">
        <div class="circle">
            <div class="checkmark"></div>
        </div>
       
    </div>

    <script>
       
        setTimeout(function() {
            window.location.href = "detallesCompra.php";
        }, 5000);
    </script>
</body>
</html>
