<?php
  session_start();  
  $Usuario= $_POST["Usuario"];
  $email =$_POST["Email"];
    $date = $_POST["FechadeNacimiento"];
    $Contraseña = $_POST ["Contraseña"];
    $password = "alumnoipm";
    $servername = "127.0.0.1";
    $database = "basededatos";
    $username = "alumno";
   
   
   
    $conexion = mysqli_connect($servername, $username, $password, $database); // se crea la conexion
 
    if (!$conexion) {
      die("Conexion fallida: " . mysqli_connect_error());
  }
  else{
      $query = "select * from usuario";
      $resultado=mysqli_query($conexion, $query);
     
          while($fila = mysqli_fetch_assoc($resultado)){
              if($fila["email"] === $email ){
               
                  header("Location: reg.php?error=1");
                  exit;
              }
           
          }
            $query = "insert into usuario value('$Usuario', '$email','$date',  '$Contraseña');";
            $_SESSION["Usuario"] = $Usuario;
            $_SESSION["Email"] = $email;
            $_SESSION["FechadeNacimiento"] = $date;
            $_SESSION["Contraseña"] = $Contraseña;
              
              
              $_SESSION["iniciada"] = true;
            
              
              $resultado=mysqli_query($conexion, $query);
              
         
      }
     
       
 
 
  mysqli_close($conexion);
?>
</body>
</html>
