<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" href="PeliculaImagenes/logoPrincipio.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro|Movie Max</title>
    <link rel="stylesheet" href="reg.css" />
    <link
    href="https://fonts.google.com/specimen/Kanit"
    rel="stylesheet"
    type="text/css" />
</head>
<body>
   
<form class="form"  action="form.php" method = "post">
    <p class="title">Registrarse </p>

        <div class="flex">
       
    </div> 
    <label>
        <input class="input" type="Usuario" required placeholder="" name="Usuario">
        <span>Usuario</span>
    </label>  
            
    <label>
        <input class="input" type="email" required placeholder="" name="Email">
        
        <span>Email</span>
        <?php if(isset($_GET['error']) && $_GET['error'] == 1){ ?>
            <label for="">Email en uso</label> <?php } ?>
    </label> 
    

            
     
          
          <div class="input-box">
          
            <input required="" required placeholder="Enter birth date" name="FechadeNacimiento" type="date">
          
        </div>
    
    <label>
        <input class="input" type="password" required placeholder="" name="Contraseña">
        <span>Contraseña</span>
    </label>
    
    <button class="submit">Continuar</button>
    <p class="signin">
        ¿Ya tiene una cuenta?
        <a href="iniciosesion.php">Iniciar Sesion</a> </p>
</form>
</body>
</html>