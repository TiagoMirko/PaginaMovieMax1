<?php
session_start();


if (isset($_SESSION['carrito']) && isset($_GET['id'])) {
    $id = $_GET['id'];

    foreach ($_SESSION['carrito'] as $index => $producto) {
        if ($producto['id'] == $id) {
            unset($_SESSION['carrito'][$index]);
            break;
        }
    }


    $_SESSION['carrito'] = array_values($_SESSION['carrito']);

   
    header("Location: mostrarcarrito.php");
}
?>
